from TWF import TWF
from Heatmap import heatmap
import matplotlib.pyplot as plt
import numpy as np
import scipy
import time 
import pandas as pd
np.random.seed(7777)

if __name__ == '__main__':
    B1 =pd.read_csv(r'B1.csv', index_col=0).values
    B2 =pd.read_csv(r'B2.csv', index_col=0).values
    B3 =pd.read_csv(r'B3.csv', index_col=0).values
    
    B = [B1, B2, B3]
    
    cov = np.zeros((100, 100))
    mean  = np.zeros(100)
    for i in range(100):
        for j in range(100):
            cov[i][j] = pow(0.3, np.abs(i - j))
    X = []
    X.append(np.random.multivariate_normal(mean=mean, cov=cov, size=60))
    X.append(np.random.multivariate_normal(mean=mean, cov=cov, size=80))
    X.append(np.random.multivariate_normal(mean=mean, cov=cov, size=100))

    Y = []
    for k in range(3):
        temp = np.random.standard_t(3, size=X[k].shape)
        temp = X[k] @ B[k] + temp
        Y.append(temp)

    X_train = [X[0][:48, :], X[1][:64, :], X[2][:80, :]]
    X_test = [X[0][48:, :], X[1][64:, :], X[2][80:, :]]
    Y_train = [Y[0][:48, :], Y[1][:64, :], Y[2][:80, :]]
    Y_test = [Y[0][48:, :], Y[1][64:, :], Y[2][80:, :]]
    begin = time.time()
    lam = np.array([0.2, 0.25, 0.25])
    model = TWF(max_iter = 30, lam_exc=0.2, lam_fus=np.array([0.25, 0.25]))
    model.fit(X_train, Y_train)
    end = time.time()
    print('Computation time:', end - begin)
    Y_pred = model.pre(X_test)
    W = np.stack([model.beta[0], model.beta[1], model.beta[2]])
    Pmse = np.mean((np.vstack(Y_pred) - np.vstack(Y_test))**2)
    print('Pmse:', Pmse)
    heatmap(W, col = 'seismic')


    

