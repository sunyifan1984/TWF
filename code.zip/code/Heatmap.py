import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
def heatmap(W, col= 'seismic'):

    fig, ax = plt.subplots(1, 3, figsize=(15, 5))
    color = col
    sns.heatmap(W[0], cmap=color, ax=ax[0], vmin=-1.3, vmax=1.3, cbar = False, yticklabels=False, xticklabels=False,
                center=0)
    ax[0].set_ylabel('CNA')
    ax[0].spines['bottom'].set_visible(True)
    ax[0].spines['left'].set_visible(True)
    ax[0].spines['top'].set_visible(True)
    ax[0].spines['right'].set_visible(True)
    ax[0].set_xlabel('GE')
    
    sns.heatmap(W[1], cmap=color, ax=ax[1], vmin=-1.3, vmax=1.3, cbar = False, yticklabels=False, xticklabels=False,
                center=0)
    ax[1].set_xlabel('GE')
    
    ax[1].spines['bottom'].set_visible(True)
    ax[1].spines['left'].set_visible(True)
    ax[1].spines['top'].set_visible(True)
    ax[1].spines['right'].set_visible(True)
    
    sns.heatmap(W[2], cmap=color, ax=ax[2], vmin=-1.3, vmax=1.3, yticklabels=False, xticklabels=False, cbar=False)
    ax[2].spines['bottom'].set_visible(True)
    ax[2].spines['left'].set_visible(True)
    ax[2].spines['top'].set_visible(True)
    ax[2].spines['right'].set_visible(True)
    ax[2].set_xlabel('GE')
    plt.show()