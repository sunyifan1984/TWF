import numpy as np
import scipy.sparse as sp
from scipy.optimize import minimize
from scipy.linalg import norm
import  matplotlib.pyplot as plt 
import seaborn as sns
import sys

def gra(beta, X, y, delta, D, HS, H, q):
    
    err = y-X.dot(beta)
    M = len(H)
    
    #-----LOSS_FUNCTION-------
    label = np.zeros_like(err)
    label[np.abs(err) <= delta] = 1
    emp_loss =  label * np.square(err) + (1-label) * ( np.abs(err) - 0.5 * delta) * delta
    emp_loss[0: HS[0]*q] = emp_loss[0: HS[0]*q] / H[0]
    for m in range(M - 1):
        emp_loss[HS[m]*q :HS[m + 1]*q] = emp_loss[HS[m]*q :HS[m + 1]*q] / H[m + 1]
    loss = np.sum(emp_loss) + beta @ D @ beta.T
    
    #---------Gradient----------
    temp = err.copy()
    temp[err > delta] = delta
    temp[err < -delta] = -delta
    temp[0: HS[0] * q] = temp[0: HS[0] * q] / H[0]
    for i in range(M - 1):
        temp[HS[i] * q: HS[i + 1]*q] = temp[HS[i] * q: HS[i + 1] * q] / H[i + 1]
    gradient = -(X.T).dot(temp) + 2 * D.dot(beta.T)
    return loss, gradient

class TWF:
    def __init__(self, max_iter=30, lam_exc=0.01, lam_fus=np.array([0.1,0.1]), epsilon = 1e-4, sigma_auto = False):
        
        '''

        lam_exc: sparsity regularization
        lam_fusr: Fusion regularization for rows
        lam_fusc: Fusion regularization for columns
        sigma_auto: True/False, if sigma_auto = True, then we update sigma according to the formula mentioned in the article.
        max_iter: the maximum number of iterations
        epsilon: the threshold used for convergence
        '''

        self.max_iter = max_iter
        self.lam_exc = lam_exc
        self.lam_fus = lam_fus
        if len(lam_fus) == 2:
            self.lam_fusc = lam_fus[0]
            self.lam_fusr = lam_fus[1]
        else:
            self.lam_fusc = lam_fus
            self.lam_fusr = lam_fus
        self.sigma_auto = sigma_auto
        self.delta = 1.35
        self.epsilon = epsilon

    def fit(self, X, Y, map =True):
        
        '''
        X: List of ndarray [n^1 * p, ..., n^M * p]
        Y: List of ndarray [n^1 * q, ..., n^M * p]
        '''
        
        H = [x.shape[0] for x in X]
        M = len(H)
        if M>=4:
            print('The Algorithm for M>=4 is not implemented yet. Please try M=2 or M=3.')
            sys.exit(1)
        HS = [sum(H[:m + 1]) for m in range(M)]

        p = X[0].shape[1]
        q = Y[0].shape[1]
        ds = p * q * M
        
        I_q = sp.identity(q, format='csc')
        D = 0.01*sp.identity(ds, format='csc')
        Xtr = []
        for m in range(M):
            Xtr.append(sp.kron(X[m], I_q, format='csc'))
        tX = sp.block_diag(Xtr, format='csc')
        # Z = \tilde{X}
        Ytr = []
        for m in range(M):
            Ytr.append(Y[m].reshape((H[m] * q, 1)))
        tbeta = np.random.randn(ds, 1)
        # tbeta = \tilde{beta}
        tY = np.vstack(Ytr)
        #tY = \tilde{Y}
        del Y, X, I_q, Xtr, Ytr
        fval = []
        for iter in range(0, self.max_iter):

            if self.sigma_auto:
                diff = tY - tX.dot(tbeta)
                temp = diff-np.median(diff)
                self.delta = 1.4826 * 1.345 * np.median(np.abs(temp))
            
            bounds = np.tile([-np.inf, np.inf], (tX.shape[1], 1))
            bounds[-1][0] = np.finfo(np.float64).eps * 10
            L_BFGS_B = minimize(gra, tbeta, method="L-BFGS-B", jac=True, args=(tX, tY.flatten(), self.delta, D, HS, H, q),
                        options={"maxiter": 100000, "gtol": 1e-4, "iprint": -1}, bounds=bounds)
            tbeta = L_BFGS_B.x.reshape(-1,1)

            A = np.zeros((p, ds))
            B = np.zeros((q, ds))

            for ii in range(M):

                temp = tbeta[ii * p * q:(ii + 1) * p * q].reshape(p, q)
                temp_temp = temp.T
                
                A[:, ii * p * q:(ii + 1) * p * q] = np.kron(np.ones(p), temp)
                B[:, ii * p * q:(ii + 1) * p * q] = np.kron(temp_temp, np.ones(q))
            
            S_Loss = self.lam_exc * np.sum(np.abs(tbeta))
            S = (self.lam_exc / (np.abs(tbeta) + 1e-5)).flatten(order='F')
            S = sp.diags(S, 0, format='csc')
            
            F_Loss = 0
            F_Loss1 = 0
            F_Loss2 = 0
            if M == 3:
                a = np.zeros(ds)
                b = np.zeros(ds)
                c = np.zeros(ds)
                d = np.zeros(ds)
                e = np.zeros(ds)

                for i in range((M - 1) * p * q):
                    for j in range(1, M):  
                        if i + j * p * q < ds:
                            
                            temp = norm((A[:, i]-A[:, i + j * p * q]), ord=2)
                            temp_temp = norm((B[:, i]-B[:, i + j * p * q]), ord=2)
                            F_Loss1 += self.lam_fusc * temp
                            F_Loss2 += self.lam_fusr * temp_temp
                            entry = -self.lam_fusc / (temp + 1e-5) - self.lam_fusr / (temp_temp + 1e-5)

                            if j == 1:
                                b[i] = entry
                            else:
                                c[i] = entry
                b[(M - 1) * p * q:] = c[:p * q]
                c[p * q:] = b[:(M - 1) * p * q]
                
                d[p * q:] = b[:(M - 1) * p * q]
                e[2 * p * q:] = b[(M - 1) * p * q:]

                b = b / M
                c = c / M
                d = d / M
                e = e / M
                a = -(b + c)
                data = np.array([c, b, a, d, e])
                index = np.array([-2 * p * q,  -p * q,  0, p * q,  2 * p * q])
                F = sp.dia_matrix((data, index), shape=(ds, ds))
                F_Loss = (F_Loss1 / p + F_Loss2 / q)/M
                F = sp.csc_matrix(F)
            
            if M == 2:
                a = np.zeros(ds)
                for i in range((M - 1) * p * q):
                    for j in range(1, M):
                        if i + j * p * q < ds:
                            temp = norm((A[:, i]-A[:, i + j * p * q]), ord=2)
                            temp_temp = norm((B[:, i]-B[:, i + j * p * q]), ord=2)
                            F_Loss1 += self.lam_fusc * temp
                            F_Loss2 += self.lam_fusr * temp_temp
                            a[i] = self.lam_fusc / (temp + 1e-5) + self.lam_fusr / (temp_temp + 1e-5)
                F_Loss = (F_Loss1 / p + F_Loss2 / q) / M
                a[p * q : ] = a[ : p * q]
                a = a/ M
                b = -a.copy()

                data = np.array([b, a, b])
                index = np.array([ -p * q, 0, p * q])
                F = sp.dia_matrix((data, index), shape=(ds, ds))
                F = sp.csc_matrix(F)
                del temp, temp_temp, A, B

            D = 0.5 * F + 0.5 * S
            
            err = tY-tX.dot(tbeta)
            label = np.zeros_like(err)
            label[np.abs(err) <= self.delta] = 1
            emp_loss =  label * np.square(err) + (1-label) * ( np.abs(err) - 0.5 * self.delta) * self.delta
            emp_loss[0: HS[0]*q] = emp_loss[0: HS[0]*q] / H[0]
            for m in range(M - 1):
                emp_loss[HS[m]*q :HS[m + 1]*q] = emp_loss[HS[m]*q :HS[m + 1]*q] / H[m + 1]
            fval.append(np.sum(emp_loss) + F_Loss + S_Loss)

            if iter > 18:
                increment_ratio = abs(fval[-1] - fval[-2]) / fval[-2]
                if increment_ratio < self.epsilon:
                    #print('iter=', iter, 'increment_ratio=', increment_ratio)
                    self.fval = np.array(fval)
                    break
        self.fval = np.array(fval)
        beta = []
        for m in range(M):
            beta.append(tbeta[m * p * q: (m + 1) * p * q].reshape(p, q))
        self.beta = beta
        
        if map:
            x_axis = np.arange(1, len(fval) + 1) 
            self.fval = np.array(fval)
            plt.figure(figsize=(10, 6))
            plt.plot(x_axis, self.fval)
            plt.xlabel('Iterations', fontsize = 14)
            plt.ylabel('Loss function', fontsize = 14)
            plt.title('Loss function VS Iterations', fontsize = 14)
            plt.plot(x_axis, self.fval, 'bo', lw=3)
            plt.show() 
        
    def pre(self, X):
        
        H = [x.shape[0] for x in X]
        M = len(H)
        Y = []
        for m in range(M):
            temp = X[m].dot(self.beta[m])
            Y.append(temp)
        return (Y)